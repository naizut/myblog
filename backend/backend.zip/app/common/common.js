
'use strict';
module.exports.error_001 = [
  'error_001',
  'something error',
];

module.exports.error_002 = [
  'error_002',
  'invalid parameter',
];

module.exports.error_003 = [
  'error_003',
  'invalid signature',
];

module.exports.error_004 = [
  'error_004',
  'no permission',
];

module.exports.error_005 = [
  'error_005',
  'please login',
];